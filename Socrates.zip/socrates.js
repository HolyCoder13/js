var allMan="mortal";
var socrates;              //Socrates
socrates=allMan;
if(socrates===allMan){
    console.log("Socrates is "+socrates);
}


let cake;
var chocolate="chocolate";

if(cake===chocolate){
    console.log("cake is chocolate")
}
else{
    console.log("cake must be a vanilla one")
}

