let firstDiv = document.getElementById("1");
firstDiv.style.backgroundColor="red";
firstDiv.style.width="90%";
firstDiv.style.height="90px";


console.log("Here are rectangle id's");
recID=(document.getElementsByClassName(".rectangle"));
console.log(recID);
